
// Author: PHNO - Tecnólogo | Pós-Graduado
// Release Date: 31/10/2024
// Version: 0.0.0.2v
// Replit: @PHNO, @PHREPLIT
// E-mail: phreplit@gmail.com

// Software: Roof Builder - 0.0.0.2v - Measurement and Calculation for Residential Roof, with Swing library and compilation in a desktop environment.

package phreplit;

	import java.awt.EventQueue;

	import javax.swing.JFrame;
	import java.awt.CardLayout;
	import java.awt.GridBagLayout;
	import javax.swing.JPanel;
	import javax.swing.JTabbedPane;
	import java.awt.Window.Type;
	import javax.swing.border.BevelBorder;
	import java.awt.SystemColor;
	import javax.swing.border.TitledBorder;
	import javax.swing.border.EtchedBorder;
	import java.awt.Color;
	import java.awt.Toolkit;
	import java.awt.Label;
	import java.awt.Panel;
	import javax.swing.JTextField;
	import javax.swing.JButton;
	import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Font;

	@SuppressWarnings("unused")
	public class RoofBuilder {

		private JFrame frmRoofBuilder;
		private JTextField textField;
		private JTextField textField_1;
		private JTextField textField_2;
		private JTextField textField_3;
		private JTextField textField_4;
		private JTextField textField_5;
		private JTextField textField_6;
		private JTextField textField_7;
		private JTextField textField_8;
		private JTextField textField_12;
		private JTextField textField_13;
		private JTextField textField_14;
		private JTextField textField_9;
		private JTextField textField_10;

		/**
		 * Launch the application.
		 */
		public static void main(String[] args) {
			EventQueue.invokeLater(new Runnable() {
				public void run() {
					try {
						RoofBuilder window = new RoofBuilder();
						window.frmRoofBuilder.setVisible(true);
					} catch (Exception e) {
						e.printStackTrace();
					}
				}
			});
		}

		/**
		 * Create the application.
		 */
		public RoofBuilder() {
			initialize();
		}

		/**
		 * Initialize the contents of the frame.
		 */
		private void initialize() {
			frmRoofBuilder = new JFrame();
			frmRoofBuilder.setIconImage(Toolkit.getDefaultToolkit().getImage(RoofBuilder.class.getResource("/phreplit/logo_40px.png")));
			frmRoofBuilder.getContentPane().setBackground(SystemColor.activeCaption);
			frmRoofBuilder.setForeground(SystemColor.activeCaption);
			frmRoofBuilder.setTitle("Roof Builder - 0.0.0.2v - Measurement and Calculation for Residential Roof");
			frmRoofBuilder.setResizable(false);
			frmRoofBuilder.setBounds(100, 100, 860, 581);
			frmRoofBuilder.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
			frmRoofBuilder.getContentPane().setLayout(null);
			
			JPanel panel = new JPanel();
			panel.setBackground(SystemColor.activeCaption);
			panel.setBorder(new TitledBorder(new EtchedBorder(EtchedBorder.LOWERED, new Color(255, 255, 255), new Color(160, 160, 160)), "1. Calculate M\u00B2 of Res. Roof [4 Equal Sides]", TitledBorder.LEADING, TitledBorder.TOP, null, new Color(0, 0, 0)));
			panel.setBounds(10, 10, 270, 282);
			frmRoofBuilder.getContentPane().add(panel);
			panel.setLayout(null);
			
			textField = new JTextField();
			textField.setBounds(10, 56, 181, 19);
			panel.add(textField);
			textField.setColumns(10);
			
			textField_1 = new JTextField();
			textField_1.setBounds(10, 105, 181, 19);
			panel.add(textField_1);
			textField_1.setColumns(10);
			
			textField_2 = new JTextField();
			textField_2.setBounds(10, 152, 181, 19);
			panel.add(textField_2);
			textField_2.setColumns(10);
			
			JButton btnNewButton = new JButton("Calculate");
			btnNewButton.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					int mult2 = Integer.parseInt(textField.getText())*Integer.parseInt(textField_1.getText());
					textField_2.setText(String.valueOf(mult2));
				}
			});
			btnNewButton.setBounds(10, 184, 98, 21);
			panel.add(btnNewButton);
			
			JButton btnNewButton_1 = new JButton("Reset");
			btnNewButton_1.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					textField.setText("");
					textField_1.setText("");
					textField_2.setText("");
					
				}
			});
			btnNewButton_1.setBounds(106, 184, 85, 21);
			panel.add(btnNewButton_1);
			
			JLabel lblNewLabel = new JLabel("Enter the roof length.:");
			lblNewLabel.setBounds(10, 33, 181, 13);
			panel.add(lblNewLabel);
			
			JLabel lblNewLabel_1 = new JLabel("Enter the roof width.:");
			lblNewLabel_1.setBounds(10, 82, 181, 13);
			panel.add(lblNewLabel_1);
			
			JLabel lblNewLabel_2 = new JLabel("Result - Square meters equal to.:");
			lblNewLabel_2.setBounds(10, 129, 181, 13);
			panel.add(lblNewLabel_2);
			
			JPanel panel_4 = new JPanel();
			panel_4.setBackground(SystemColor.activeCaption);
			panel_4.setBorder(new TitledBorder(new EtchedBorder(EtchedBorder.LOWERED, new Color(255, 255, 255), new Color(160, 160, 160)), "3. Calculate Quantity and Type of Tile per M\u00B2", TitledBorder.LEADING, TitledBorder.TOP, null, new Color(0, 0, 0)));
			panel_4.setBounds(10, 302, 270, 232);
			frmRoofBuilder.getContentPane().add(panel_4);
			panel_4.setLayout(null);
			
			JLabel lblNewLabel_12 = new JLabel("Enter the square meters obtained.:");
			lblNewLabel_12.setBounds(10, 22, 250, 13);
			panel_4.add(lblNewLabel_12);
			
			JLabel lblNewLabel_15 = new JLabel("Enter the number of tiles corresponding");
			lblNewLabel_15.setFont(new Font("Tahoma", Font.BOLD, 9));
			lblNewLabel_15.setBounds(10, 69, 235, 13);
			panel_4.add(lblNewLabel_15);
			
			JLabel lblNewLabel_16 = new JLabel("to the type of tile per m² [Conversion Table].:");
			lblNewLabel_16.setFont(new Font("Tahoma", Font.BOLD, 9));
			lblNewLabel_16.setBounds(10, 92, 235, 13);
			panel_4.add(lblNewLabel_16);
			
			JLabel lblNewLabel_17 = new JLabel("Result - The number of tiles will be (n) tile(s).:");
			lblNewLabel_17.setFont(new Font("Tahoma", Font.BOLD, 9));
			lblNewLabel_17.setBounds(10, 149, 235, 13);
			panel_4.add(lblNewLabel_17);
			
			textField_12 = new JTextField();
			textField_12.setBounds(10, 40, 180, 19);
			panel_4.add(textField_12);
			textField_12.setColumns(10);
			
			textField_13 = new JTextField();
			textField_13.setBounds(10, 115, 180, 19);
			panel_4.add(textField_13);
			textField_13.setColumns(10);
			
			textField_14 = new JTextField();
			textField_14.setBounds(10, 172, 180, 19);
			panel_4.add(textField_14);
			textField_14.setColumns(10);
			
			JButton btnNewButton_8 = new JButton("Calculate");
			btnNewButton_8.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					int mult8 = Integer.parseInt(textField_12.getText())*Integer.parseInt(textField_13.getText());
					textField_14.setText(String.valueOf(mult8));
				}
			});
			btnNewButton_8.setBounds(10, 201, 98, 21);
			panel_4.add(btnNewButton_8);
			
			JButton btnNewButton_9 = new JButton("Reset");
			btnNewButton_9.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					textField_12.setText("");
					textField_13.setText("");
					textField_14.setText("");
					
				}
			});
			btnNewButton_9.setBounds(105, 201, 85, 21);
			panel_4.add(btnNewButton_9);
			
			JPanel panel_5 = new JPanel();
			panel_5.setBackground(SystemColor.activeCaption);
			panel_5.setBorder(new TitledBorder(new EtchedBorder(EtchedBorder.LOWERED, new Color(255, 255, 255), new Color(160, 160, 160)), "Conversion Table", TitledBorder.LEADING, TitledBorder.TOP, null, new Color(0, 0, 0)));
			panel_5.setBounds(290, 302, 264, 232);
			frmRoofBuilder.getContentPane().add(panel_5);
			panel_5.setLayout(null);
			
			JLabel lblNewLabel_13 = new JLabel("American Tile");
			lblNewLabel_13.setBounds(38, 58, 97, 13);
			panel_5.add(lblNewLabel_13);
			
			JLabel lblNewLabel_18 = new JLabel("Colonial Tile");
			lblNewLabel_18.setBounds(38, 81, 97, 13);
			panel_5.add(lblNewLabel_18);
			
			JLabel lblNewLabel_19 = new JLabel("Italian Tile");
			lblNewLabel_19.setBounds(38, 104, 97, 13);
			panel_5.add(lblNewLabel_19);
			
			JLabel lblNewLabel_20 = new JLabel("Portuguese Tile");
			lblNewLabel_20.setBounds(38, 127, 97, 13);
			panel_5.add(lblNewLabel_20);
			
			JLabel lblNewLabel_7 = new JLabel("Roman Tile");
			lblNewLabel_7.setBounds(38, 150, 97, 13);
			panel_5.add(lblNewLabel_7);
			
			JLabel lblNewLabel_9 = new JLabel("Tile of Another Model");
			lblNewLabel_9.setBounds(24, 173, 109, 13);
			panel_5.add(lblNewLabel_9);
			
			JLabel lblNewLabel_11 = new JLabel("12 tiles per 1M²");
			lblNewLabel_11.setBounds(143, 58, 111, 13);
			panel_5.add(lblNewLabel_11);
			
			JLabel lblNewLabel_14 = new JLabel("16 tiles per 1M²");
			lblNewLabel_14.setBounds(143, 81, 111, 13);
			panel_5.add(lblNewLabel_14);
			
			JLabel lblNewLabel_21 = new JLabel("14 tiles per 1M²");
			lblNewLabel_21.setBounds(143, 104, 111, 13);
			panel_5.add(lblNewLabel_21);
			
			JLabel lblNewLabel_22 = new JLabel("17 tiles per 1M²");
			lblNewLabel_22.setBounds(143, 127, 111, 13);
			panel_5.add(lblNewLabel_22);
			
			JLabel lblNewLabel_23 = new JLabel("16 tiles per 1M²");
			lblNewLabel_23.setBounds(143, 150, 111, 13);
			panel_5.add(lblNewLabel_23);
			
			JLabel lblNewLabel_24 = new JLabel("(N) tiles per 1M²");
			lblNewLabel_24.setBounds(143, 173, 111, 13);
			panel_5.add(lblNewLabel_24);
			
			JPanel panel_7 = new JPanel();
			panel_7.setBackground(SystemColor.activeCaption);
			panel_7.setBorder(new TitledBorder(null, "Setup", TitledBorder.LEADING, TitledBorder.TOP, null, null));
			panel_7.setBounds(564, 302, 270, 232);
			frmRoofBuilder.getContentPane().add(panel_7);
			panel_7.setLayout(null);
			
			JButton btnNewButton_14 = new JButton("Info");
			btnNewButton_14.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					JOptionPane.showMessageDialog(
							null,"Info\n"
				                + "\nTo calculate the square meter of the roof with 4 equal sides [equal footage] we calculate Length x Width."
				                + "\nTo calculate the square meter with 4 different sides [different footage] we add the two parallel sides, "
				                + "\nwe add the length to the length and divide it by 2, thus taking the average, "
				                + "\nwe do the same with the width, we add the width to the width and divide by 2 taking the average, "
				                + "\nand with the results of the average of the parallel sides (width and length) "
				                + "\nwe multiply the two parallel sides Length x Width and thus we obtain the square meters of a roof with 4 different sides.\n"
				                + "\nTo calculate the Quantity of Tiles per Square Meter: \n"
				                + "\nTaking as an example an American tile with dimensions (43Lx26W) in centimeters in horizontal axis view, "
				                + "\nand knowing that calculating a square meter of a roof will be L x W then 1 Square Meter = 12 tiles, "
				                + "\nso one square meter has 12 tiles so this will be the standard measurement. 12 x so many square meters = the amount of tiles per square meter.\n"
				                + "\nTo calculate the Colonial Tile: 1 M² = 16 tiles."
				                + "\nTo calculate the Italian Tile: 1 M² = 14 tiles."
				                + "\nTo calculate the Portuguese Tile: 1 M² = 17 tiles.\n"
				                + "\nTo calculate the Roman Tile: \n"
				                + "\nTaking as an example a Roman tile with dimensions (40Lx21W) in centimeters in horizontal axis view, "
				                + "\nand knowing that calculating a square meter of a roof will be L x W then 1 Square Meter = 16 tiles,"
				                + "\n so one square meter has 16 tiles so this will be the standard measurement. 16 x so many square meters = the number of tiles per square meter.\n"
				                + "\nImportant Information: \n"
				                + "\nNote: This software was developed with integer variables, so it does not allow the insertion of numbers and commas. (ex: 2.90 meters change to 3 meters)."
				                + "\nNote: The calculation of the square meter of a residential roof in this software is done without calculating the slope. "
				                + "\nIf the calculation of the square meter is done with the slope, with the increase in the degree of inclination of the roof,"
				                + "\nThere will be an increase in the amount of tiles needed to tile and build a residential roof."
				                + "\nNote: the installation, construction and dimensioning of a residential roof requires a qualified and trained professional, such as a civil engineer. \n"
				                + "\nTile Pattern per Square Meter and Quantity of Tiles: \n"
				                + "\n The number of tiles can vary for more tiles or fewer tiles, depending on the dimensions of the chosen tile, "
				                + "\nso see that in the case of installing colonial tiles, the arrangement (fitting) of the tiles will be done with two layers of tiles, "
				                + "\nwhich can lead to variations (more or less) in the number of tiles needed to cover one square meter."
				                + "\n There is therefore a possible difference in the pattern and quantity of tiles per square meter for colonial tiles as described above.\n"
				                + "\nTile Model per Square Meter and Quantity of Tiles: \n"
				                + "\nIf you want to calculate a new tile model that is not in the conversion table, you will need to know the dimensions of the new tile model "
				                + "\nand know how many tiles will be needed to cover one square meter, so it will be (N) tiles per 1M².");

				}
			});
			btnNewButton_14.setBounds(95, 67, 85, 21);
			panel_7.add(btnNewButton_14);
			
			JButton btnNewButton_15 = new JButton("About");
			btnNewButton_15.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					JOptionPane.showMessageDialog(
							null,"Software:  Roof Builder - Measurement and Calculation for Residential Roof\n"
							+"\nAuthor: PHNO"
							+"\nRelease Date: 31/10/2024"
							+"\nVersion: 0.0.0.2v"
							+"\nReplit: @PHNO, @PHREPLIT"
							+"\nE-mail: phreplit@gmail.com");
				}
			});
			btnNewButton_15.setBounds(95, 98, 85, 21);
			panel_7.add(btnNewButton_15);
			
			JButton btnNewButton_16 = new JButton("Clear Data");
			btnNewButton_16.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					textField.setText("");
					textField_1.setText("");
					textField_2.setText("");
					textField_3.setText("");
					textField_4.setText("");
					textField_5.setText("");
					textField_6.setText("");
					textField_7.setText("");
					textField_8.setText("");
					textField_9.setText("");
					textField_10.setText("");
					textField_12.setText("");
					textField_13.setText("");
					textField_14.setText("");
					
				}
			});
			btnNewButton_16.setBounds(81, 129, 112, 21);
			panel_7.add(btnNewButton_16);
			
			JPanel panel_1 = new JPanel();
			panel_1.setBackground(SystemColor.activeCaption);
			panel_1.setBorder(new TitledBorder(new EtchedBorder(EtchedBorder.LOWERED, new Color(255, 255, 255), new Color(160, 160, 160)), "2. Calculate M\u00B2 of Res. Roof [4 Different Sides]", TitledBorder.LEADING, TitledBorder.TOP, null, new Color(0, 0, 0)));
			panel_1.setBounds(290, 10, 264, 282);
			frmRoofBuilder.getContentPane().add(panel_1);
			panel_1.setLayout(null);
			
			JLabel lblNewLabel_3 = new JLabel("Enter Roof Length [Side 1].:");
			lblNewLabel_3.setBounds(10, 30, 180, 13);
			panel_1.add(lblNewLabel_3);
			
			JLabel lblNewLabel_4 = new JLabel("Enter Roof Length [Side 2].:");
			lblNewLabel_4.setBounds(10, 71, 180, 13);
			panel_1.add(lblNewLabel_4);
			
			JLabel lblNewLabel_5 = new JLabel("Enter Roof Width [Side 3].:");
			lblNewLabel_5.setBounds(10, 114, 180, 13);
			panel_1.add(lblNewLabel_5);
			
			textField_3 = new JTextField();
			textField_3.setBounds(10, 46, 180, 19);
			panel_1.add(textField_3);
			textField_3.setColumns(10);
			
			textField_4 = new JTextField();
			textField_4.setBounds(10, 92, 180, 19);
			panel_1.add(textField_4);
			textField_4.setColumns(10);
			
			textField_5 = new JTextField();
			textField_5.setBounds(10, 134, 180, 19);
			panel_1.add(textField_5);
			textField_5.setColumns(10);
			
			JButton btnNewButton_2 = new JButton("Calculate");
			btnNewButton_2.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					int vartwo = 2;			                
					int mult3 = Integer.parseInt(textField_3.getText())+Integer.parseInt(textField_4.getText());
	                int mult4 = mult3 / vartwo;			                
	                int mult5 = Integer.parseInt(textField_5.getText())+Integer.parseInt(textField_9.getText());
	                int mult6 = mult5 / vartwo;
	                int result = mult4 * mult6;			                
					textField_10.setText(String.valueOf(result));
				}
			});
			btnNewButton_2.setBounds(10, 240, 98, 21);
			panel_1.add(btnNewButton_2);
			
			JButton btnNewButton_3 = new JButton("Reset");
			btnNewButton_3.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					textField_3.setText("");
					textField_4.setText("");
					textField_5.setText("");
					textField_9.setText("");
					textField_10.setText("");
					
				}
			});
			btnNewButton_3.setBounds(105, 240, 85, 21);
			panel_1.add(btnNewButton_3);
			
			JLabel lblNewLabel_25 = new JLabel("Enter Roof Width [Side 4].:");
			lblNewLabel_25.setBounds(10, 156, 180, 13);
			panel_1.add(lblNewLabel_25);
			
			textField_9 = new JTextField();
			textField_9.setBounds(10, 172, 180, 19);
			panel_1.add(textField_9);
			textField_9.setColumns(10);
			
			JLabel lblNewLabel_26 = new JLabel("Result - Square meters equal to.:");
			lblNewLabel_26.setBounds(10, 195, 244, 13);
			panel_1.add(lblNewLabel_26);
			
			textField_10 = new JTextField();
			textField_10.setBounds(10, 211, 180, 19);
			panel_1.add(textField_10);
			textField_10.setColumns(10);
			
			JPanel panel_2 = new JPanel();
			panel_2.setBackground(SystemColor.activeCaption);
			panel_2.setBorder(new TitledBorder(new EtchedBorder(EtchedBorder.LOWERED, new Color(255, 255, 255), new Color(160, 160, 160)), "Basic Calculator", TitledBorder.LEADING, TitledBorder.TOP, null, new Color(0, 0, 0)));
			panel_2.setBounds(564, 10, 271, 280);
			frmRoofBuilder.getContentPane().add(panel_2);
			panel_2.setLayout(null);
			
			JLabel lblNewLabel_6 = new JLabel("Enter number.:");
			lblNewLabel_6.setBounds(10, 33, 110, 13);
			panel_2.add(lblNewLabel_6);
			
			textField_6 = new JTextField();
			textField_6.setBounds(10, 56, 110, 19);
			panel_2.add(textField_6);
			textField_6.setColumns(10);
			
			textField_7 = new JTextField();
			textField_7.setBounds(10, 107, 110, 19);
			panel_2.add(textField_7);
			textField_7.setColumns(10);
			
			textField_8 = new JTextField();
			textField_8.setBounds(10, 160, 110, 19);
			panel_2.add(textField_8);
			textField_8.setColumns(10);
			
			JLabel lblNewLabel_8 = new JLabel("Enter another number.:");
			lblNewLabel_8.setBounds(10, 85, 137, 13);
			panel_2.add(lblNewLabel_8);
			
			JLabel lblNewLabel_10 = new JLabel("Result.:");
			lblNewLabel_10.setBounds(10, 137, 45, 13);
			panel_2.add(lblNewLabel_10);
			
			JButton btnNewButton_4 = new JButton("Sum");
			btnNewButton_4.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					int soma = Integer.parseInt(textField_6.getText())+Integer.parseInt(textField_7.getText());
					textField_8.setText(String.valueOf(soma));
				}
			});
			btnNewButton_4.setBounds(148, 55, 85, 21);
			panel_2.add(btnNewButton_4);
			
			JButton btnNewButton_5 = new JButton("Reset");
			btnNewButton_5.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					textField_6.setText("");
					textField_7.setText("");
					textField_8.setText("");
					
				}
			});
			btnNewButton_5.setBounds(10, 189, 85, 21);
			panel_2.add(btnNewButton_5);
			
			JButton btnNewButton_6 = new JButton("Subtract");
			btnNewButton_6.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					int sub = Integer.parseInt(textField_6.getText())-Integer.parseInt(textField_7.getText());
					textField_8.setText(String.valueOf(sub));
				}
			});
			btnNewButton_6.setBounds(148, 85, 85, 21);
			panel_2.add(btnNewButton_6);
			
			JButton btnNewButton_7 = new JButton("Divide");
			btnNewButton_7.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					int div = Integer.parseInt(textField_6.getText())/Integer.parseInt(textField_7.getText());
					textField_8.setText(String.valueOf(div));
				}
			});
			btnNewButton_7.setBounds(148, 117, 85, 21);
			panel_2.add(btnNewButton_7);
			
			JButton btnNewButton_10 = new JButton("Multiply");
			btnNewButton_10.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					int mult = Integer.parseInt(textField_6.getText())*Integer.parseInt(textField_7.getText());
					textField_8.setText(String.valueOf(mult));
				}
			});
			btnNewButton_10.setBounds(148, 148, 85, 21);
			panel_2.add(btnNewButton_10);
		}
	}
